SM_Industries
Tony Jones 03 July 2017 

SM Mods localisation for all SM Managed and owned KSP mods 
This is the combined dictionary for SM Armory, SM Marine,  SM AFV's , Large Boat Parts Modern WW2 and Parts required
To use in combination with any of the forenamed KSP Mods place one (1) copy of the SMIndustries folder withing your GameData folder.

It is now a requirement that SM_Industries is used alongside the forenamed mods, it is not an optional feature 
This work provides the larger part of the EN_US localisation and will be added to as other managed mods are in turn processed for localisation .  Failure to use 1 copy of this dictionary in combination with the above named KSP mods will result in descriptions and titles being rendered as meaningless strings 

The bulk of the dictionary work was created and assembled by @gomker, using a combination of scripts in order to process such a large amount of individual parts . 

Credits 
gomker , primary provider of localised materials, extensive testing, and bespoke code alteration and creation
TriggerAU , deleoped the original script from which gomker developed the bulk methods used.
XOC2008,  testing and quality control, provider of inspiration
V8Jester, play testing